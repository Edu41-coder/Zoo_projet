<?php
    define('BDD_LOGIN', 'root');
    define('BDD_PASSWORD', 'root'); 
    define('BDD_SERVER', 'localhost');
    define('BDD_DATABASE', 'zoo');
